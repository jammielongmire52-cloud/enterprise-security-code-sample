import { Request, Response, NextFunction } from "express";
import { AuthenticationError, AuthorizationError, AppError } from "./errors";

/**
 * Server-side permission gate. The UI is never treated as the security
 * boundary: sensitive routes name the exact permission they require.
 */
export function requirePermission(...requiredPermissions: string[]) {
  const middleware = (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.authContext) return next(new AuthenticationError());

    const allowed = requiredPermissions.every((permission) =>
      req.authContext!.permissions.includes(permission),
    );

    if (!allowed) {
      return next(
        new AuthorizationError(
          `Missing required permission(s): ${requiredPermissions.join(", ")}`,
        ),
      );
    }

    next();
  };

  return Object.assign(middleware, { requiredPermissions });
}

/** Requires a selected tenant for tenant-scoped operations. */
export function requireTenantContext(
  req: Request,
  _res: Response,
  next: NextFunction,
): void {
  if (!req.authContext) return next(new AuthenticationError());
  if (!req.authContext.tenantId) {
    return next(new AuthorizationError("This action requires an active tenant context"));
  }
  next();
}

/**
 * Defense against Tenant A requesting a Tenant B resource by changing a URL
 * parameter. The authenticated tenant must match the requested tenant.
 */
export function enforceTenantParamMatch(paramName = "tenantId") {
  const middleware = (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.authContext) return next(new AuthenticationError());

    const requestedTenant = req.params[paramName];
    if (requestedTenant && requestedTenant !== req.authContext.tenantId) {
      return next(new AuthorizationError("Cross-tenant access is not permitted"));
    }

    next();
  };

  return Object.assign(middleware, { tenantGuard: true });
}

export class ReauthenticationRequiredError extends AppError {
  constructor() {
    super("Recent authentication required", 401, "REAUTH_REQUIRED");
  }
}

/** Step-up authentication gate for sensitive operations. */
export function requireRecentAuth(maxAgeSeconds = 300) {
  const middleware = (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.authContext) return next(new AuthenticationError());

    const age = Math.floor(Date.now() / 1000) - req.authContext.authTime;
    if (!req.authContext.authTime || age > maxAgeSeconds) {
      return next(new ReauthenticationRequiredError());
    }

    next();
  };

  return Object.assign(middleware, { recentAuthSeconds: maxAgeSeconds });
}

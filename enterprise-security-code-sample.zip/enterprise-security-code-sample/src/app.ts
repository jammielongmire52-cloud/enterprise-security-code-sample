import "./types";
import express, { NextFunction, Request, Response } from "express";
import { ROLE_PERMISSIONS, RoleName } from "./permissions";
import { AppError } from "./errors";
import {
  enforceTenantParamMatch,
  requirePermission,
  requireRecentAuth,
  requireTenantContext,
} from "./authorize";

export function createApp() {
  const app = express();
  app.use(express.json());

  // Standalone demo harness only. In the source platform, authentication is
  // JWT + database backed. Headers make authorization behavior easy to test.
  app.use((req, _res, next) => {
    const role = req.header("x-role") as RoleName | undefined;
    const tenantId = req.header("x-tenant-id") ?? null;
    const authTime = Number(req.header("x-auth-time") ?? Math.floor(Date.now() / 1000));

    if (role && ROLE_PERMISSIONS[role]) {
      req.authContext = {
        userId: "sample-user",
        organizationId: "sample-org",
        tenantId,
        roleName: role,
        permissions: ROLE_PERMISSIONS[role],
        authTime,
      };
    }
    next();
  });

  app.get(
    "/tenants/:tenantId/audit",
    requireTenantContext,
    enforceTenantParamMatch(),
    requirePermission("audit:view"),
    (_req, res) => res.json({ ok: true }),
  );

  app.delete(
    "/tenants/:tenantId",
    requireTenantContext,
    enforceTenantParamMatch(),
    requirePermission("tenant:delete"),
    requireRecentAuth(300),
    (_req, res) => res.status(204).send(),
  );

  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof AppError) {
      return res.status(err.statusCode).json({ error: err.code, message: err.message });
    }
    return res.status(500).json({ error: "INTERNAL_ERROR" });
  });

  return app;
}

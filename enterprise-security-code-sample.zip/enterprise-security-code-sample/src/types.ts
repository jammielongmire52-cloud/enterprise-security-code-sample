import "express";

declare global {
  namespace Express {
    interface Request {
      authContext?: {
        userId: string;
        organizationId: string;
        tenantId: string | null;
        roleName: string | null;
        permissions: string[];
        authTime: number;
      };
    }
  }
}

export {};

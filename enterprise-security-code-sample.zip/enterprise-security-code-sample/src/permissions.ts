/**
 * SINGLE SOURCE OF TRUTH for tenant authorization (Section 5).
 * Consumed by: registration (role creation), prisma/seed.ts (catalog),
 * the role migration (verified equal by test), the permission-matrix test,
 * and the generated route inventory. Every permission below is enforced by
 * at least one route; unused permissions were removed rather than granted.
 */

export const PERMISSIONS = {
  "tenant:view": "Read basic tenant details",
  "tenant:manage_members": "List members, change non-Owner roles, remove non-Owner members",
  "tenant:transfer_ownership": "Grant the Owner role / step down as Owner",
  "tenant:delete": "Irreversibly delete the tenant and all its data",
  "audit:view": "Read the tenant audit log",
  "datasource:view": "Read data sources, discovered tables and job status",
  "datasource:create": "Register a new connector (writes encrypted credentials)",
  "datasource:test_connection": "Open a live test connection to a connector",
  "datasource:run_jobs": "Queue discovery and quality jobs against a connector",
  "datasource:manage_credentials": "Change connector TLS settings / private CA",
  "catalog:view": "Read catalog, quality history, lineage, graph, trust scores",
  "catalog:manage": "Edit catalog descriptions, ownership and manual classifications",
  "policy:view": "Read policies and violations",
  "policy:manage": "Create and change governance policies",
  "policy:evaluate": "Run detective policy evaluation",
  "ai:view": "Read AI agents and invocation history",
  "ai:invoke": "Ask questions of a governed AI agent",
  "ai:manage": "Register AI agents and set their owners",
  "decision:view": "Read recommendations and decisions",
  "decision:generate": "Generate recommendations from current signals",
  "decision:manage": "Record decisions on recommendations",
  "privacy:purge": "Purge records past their retention window",
} as const;

export type PermissionKey = keyof typeof PERMISSIONS;
export type RoleName = "OWNER" | "ADMIN" | "OPERATOR" | "ANALYST" | "VIEWER";

const VIEWER: PermissionKey[] = ["tenant:view", "datasource:view", "catalog:view", "policy:view", "ai:view", "decision:view"];
const ANALYST_EXTRA: PermissionKey[] = ["ai:invoke", "policy:evaluate", "decision:generate"];
const OPERATOR_EXTRA: PermissionKey[] = ["datasource:create", "datasource:test_connection", "datasource:run_jobs", "datasource:manage_credentials"];
const ADMIN_EXTRA: PermissionKey[] = ["tenant:manage_members", "audit:view", "catalog:manage", "policy:manage", "ai:manage", "decision:manage", "privacy:purge"];
const OWNER_EXTRA: PermissionKey[] = ["tenant:transfer_ownership", "tenant:delete"];

export const ROLE_PERMISSIONS: Record<RoleName, PermissionKey[]> = {
  VIEWER,
  ANALYST: [...VIEWER, ...ANALYST_EXTRA],
  OPERATOR: [...VIEWER, ...OPERATOR_EXTRA],
  ADMIN: [...VIEWER, ...ANALYST_EXTRA, ...OPERATOR_EXTRA, ...ADMIN_EXTRA],
  OWNER: [...VIEWER, ...ANALYST_EXTRA, ...OPERATOR_EXTRA, ...ADMIN_EXTRA, ...OWNER_EXTRA],
};

export const ROLE_DESCRIPTIONS: Record<RoleName, string> = {
  OWNER: "Tenant ownership and irreversible operations (ownership transfer, tenant deletion)",
  ADMIN: "Tenant administration: members, policies, catalog curation, AI agents, retention purge",
  OPERATOR: "Manage connectors (incl. credentials/TLS) and run operational jobs",
  ANALYST: "Read data, invoke AI, evaluate policies, generate recommendations",
  VIEWER: "Read permitted results only",
};

/** Rank for member-management rules. OPERATOR and ANALYST are peers. */
export const ROLE_RANK: Record<RoleName, number> = { OWNER: 4, ADMIN: 3, OPERATOR: 2, ANALYST: 2, VIEWER: 1 };
export const ROLE_NAMES = Object.keys(ROLE_PERMISSIONS) as RoleName[];
export function isRoleName(n: string): n is RoleName {
  return (ROLE_NAMES as string[]).includes(n);
}

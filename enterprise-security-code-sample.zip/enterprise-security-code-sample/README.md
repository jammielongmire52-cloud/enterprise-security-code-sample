# Enterprise Security Code Sample

A small, standalone TypeScript reference implementation extracted and simplified from a larger enterprise intelligence platform I designed and developed with AI-assisted engineering tools.

The purpose of this repository is to demonstrate how I approach authorization as a server-side security boundary rather than a UI feature.

## What this sample demonstrates

- Centralized role-based access control (RBAC)
- Explicit permission checks at the API boundary
- Multi-tenant isolation using authenticated tenant context
- Step-up / recent-authentication requirements for sensitive operations
- Automated tests for denied and permitted authorization paths
- A deliberately small Express harness so the security behavior can be reviewed and run independently

## Security model

The permission catalog is the single source of truth for five roles: `VIEWER`, `ANALYST`, `OPERATOR`, `ADMIN`, and `OWNER`.

Routes compose small authorization gates:

1. `requireTenantContext` ensures a tenant is selected.
2. `enforceTenantParamMatch` prevents a caller authenticated to Tenant A from changing a URL and accessing Tenant B.
3. `requirePermission` verifies the exact capability required by a route.
4. `requireRecentAuth` adds step-up authentication for sensitive operations such as tenant deletion.

The original platform loads permissions from current database membership on every authenticated request. This public sample replaces that private authentication/database layer with test headers so the authorization behavior remains easy to inspect and run without exposing the larger system.

## Run it

```bash
npm install
npm test
npm run typecheck
```

## Repository layout

```text
src/
  app.ts           Standalone Express test harness
  authorize.ts     Authorization and tenant-isolation middleware
  errors.ts        Small typed error model
  permissions.ts   Permission catalog and role mappings
  types.ts         Express authentication-context typing

tests/
  authorization.test.ts
  tenant-isolation.test.ts
```

## Why I selected this sample

I am proud of this part of the system because it represents an engineering principle I care about: security rules should be explicit, centralized, testable, and enforced on the server.

I use AI-assisted development tools, including Claude Code and Codex, to accelerate implementation and analysis. I do not treat generated code as automatically correct. My workflow includes architecture decisions, code review, adversarial testing, security audits, regression testing, and iterative hardening.

The larger source platform includes authentication, PostgreSQL/Prisma persistence, Redis-backed workers, encrypted credentials, audit logging, connector security, and broader production-hardening controls. Those components are intentionally excluded here so this repository stays focused and does not expose the full proprietary platform.

## Scope note

This repository is a portfolio code sample, not a production authentication service. The header-based identity setup in `src/app.ts` exists only to make the authorization layer independently runnable. Production identity verification belongs upstream of these authorization controls.

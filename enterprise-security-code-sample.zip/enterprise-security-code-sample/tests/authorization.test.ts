import request from "supertest";
import { createApp } from "../src/app";

describe("permission authorization", () => {
  const app = createApp();

  it("rejects unauthenticated requests", async () => {
    const response = await request(app).get("/tenants/acme/audit");
    expect(response.status).toBe(401);
    expect(response.body.error).toBe("AUTHENTICATION_ERROR");
  });

  it("rejects a viewer that lacks audit:view", async () => {
    const response = await request(app)
      .get("/tenants/acme/audit")
      .set("x-role", "VIEWER")
      .set("x-tenant-id", "acme");

    expect(response.status).toBe(403);
    expect(response.body.message).toContain("audit:view");
  });

  it("allows an admin with audit:view", async () => {
    const response = await request(app)
      .get("/tenants/acme/audit")
      .set("x-role", "ADMIN")
      .set("x-tenant-id", "acme");

    expect(response.status).toBe(200);
    expect(response.body).toEqual({ ok: true });
  });

  it("requires recent authentication for irreversible owner operations", async () => {
    const stale = Math.floor(Date.now() / 1000) - 600;
    const response = await request(app)
      .delete("/tenants/acme")
      .set("x-role", "OWNER")
      .set("x-tenant-id", "acme")
      .set("x-auth-time", String(stale));

    expect(response.status).toBe(401);
    expect(response.body.error).toBe("REAUTH_REQUIRED");
  });
});

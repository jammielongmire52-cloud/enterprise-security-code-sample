import request from "supertest";
import { createApp } from "../src/app";

describe("tenant isolation", () => {
  const app = createApp();

  it("blocks Tenant A from requesting Tenant B resources", async () => {
    const response = await request(app)
      .get("/tenants/tenant-b/audit")
      .set("x-role", "ADMIN")
      .set("x-tenant-id", "tenant-a");

    expect(response.status).toBe(403);
    expect(response.body.message).toBe("Cross-tenant access is not permitted");
  });

  it("allows access when authenticated and requested tenants match", async () => {
    const response = await request(app)
      .get("/tenants/tenant-a/audit")
      .set("x-role", "ADMIN")
      .set("x-tenant-id", "tenant-a");

    expect(response.status).toBe(200);
  });
});
